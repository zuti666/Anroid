package com.myapplication.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.myapplication.R;
import com.myapplication.util.DBHelper2;

public class ForgetPasswordActivity extends AppCompatActivity {

    private TextView fUserName;
    private TextView fPwd;
    private Button findPwd;
    private Button returnLogin;

    com.myapplication.util.DBHelper2 dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        fUserName = (TextView) findViewById(R.id.fUserName);
        fPwd = (TextView) findViewById(R.id.fPwd);
        findPwd = (Button) findViewById(R.id.findPwd);
        returnLogin = (Button) findViewById(R.id.returnLogin);

        dbHelper = new DBHelper2(ForgetPasswordActivity.this);

        //从Intent 中获得用户名
        final String userNameF = getIntent().getStringExtra("fUserName");
        fUserName.setText(userNameF);

        //点击找回密码按钮，显示注册时密码
        findPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //从数据库中查询密码
                String password = dbHelper.queryPasswordByName(userNameF);
                fPwd .setText(password);
                //显示出来
            }
        });

        returnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(ForgetPasswordActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });


    }
}
