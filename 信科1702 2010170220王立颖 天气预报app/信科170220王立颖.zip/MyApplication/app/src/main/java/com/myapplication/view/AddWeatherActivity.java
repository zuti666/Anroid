package com.myapplication.view;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.myapplication.MainActivity;
import com.myapplication.R;
import com.myapplication.json.MyJson;
import com.myapplication.utinity.Weather;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.ValueShape;
import lecho.lib.hellocharts.view.LineChartView;


public class AddWeatherActivity extends AppCompatActivity {


    private ViewPager viewPager;

    ArrayList<View> vpList;
    ;



    private Button plusButton;
    private TextView selectCity;











    //线形图的属性
    //横轴的刻度
    String[] lineData ={"今天","明天","后天"};

    //温度数据点
    int[] temperatureHigh={24,27,28};
    int[] temperatureLow={24,27,28};



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weather);

        plusButton = (Button) findViewById(R.id.plusButton);
        selectCity = (TextView) findViewById(R.id.selectCity);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        LayoutInflater layoutInflater = LayoutInflater.from(this);




        //根据参数查询数据 添加到tempatureView中 并绘制LineView


//接受intent传过来的参数

        final ArrayList<String>  cityList = getIntent().getStringArrayListExtra("cityList");
        final  String city1 = getIntent().getStringExtra("city1");


        vpList = new ArrayList<View>();

        //先实现第一个
        //final String city1 = cityList.get(0);

        final  View v1 = layoutInflater.inflate(R.layout.tempatureview,null);


        final String city2 = getIntent().getStringExtra("city2");
        //final String city2 = cityList.get(1);

        final View v2 = layoutInflater.inflate(R.layout.tempatureview, null);

        //final  String city3 = cityList.get(2);
        final String city3 = getIntent().getStringExtra("city3");
        final View v3 = layoutInflater.inflate(R.layout.tempatureview, null);



        //根据参数查询数据
        if(city1!=null && city1!="") {
            new Thread() {
                public void run() {
                    try {
                        final ArrayList<Weather> arrayList1;
                        String path = "https://api.seniverse.com/v3/weather/daily.json?key=SZRF79U_WCU9O3B-c&location=" + city1
                                + "&language=zh-Hans&unit=c&start=0&days=3";
                        URL url = new URL(path);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setReadTimeout(5000);
                        conn.setRequestMethod("GET");
                        if (conn.getResponseCode() == 200) {
                            InputStream inputStream = conn.getInputStream();
                            String str = "";
                            int len = 0;
                            byte[] bytes = new byte[1024];
                            while ((len = inputStream.read(bytes)) > 20) {
                                str += new String(bytes);

                            }
                            //查询结果
                            arrayList1 = MyJson.getWeather(str);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //添加到tempatureView
                                    //保存到list中
                                    //listView//数据值的点
                                    List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
                                    List<PointValue> pointValues = new ArrayList<PointValue>();
                                    List<PointValue> pointValues1 = new ArrayList<PointValue>();
                                    List<AxisValue> axisValues = new ArrayList<AxisValue>();
                                    ListView weatherListView = (ListView) v1.findViewById(R.id.weatherListView);
                                    for (int i = 0; i < 3; i++) {
                                        Map<String, Object> map = new HashMap<String, Object>();
                                        map.put("city", city1);
                                        map.put("date", arrayList1.get(i).getDate());
                                        map.put("low", arrayList1.get(i).getLow());
                                        map.put("high", arrayList1.get(i).getHigh());
                                        map.put("text_day", arrayList1.get(i).getText_day());
                                        map.put("text_night", arrayList1.get(i).getText_night());

                                        //根据天气代码查询天气图标
                                        map.put("code_day", arrayList1.get(i).getCode_day());
                                        map.put("code_night", arrayList1.get(i).getCode_night());

                                        String codeDay = arrayList1.get(i).getCode_day();
                                        String codeNight = arrayList1.get(i).getCode_night();
                                        Object oDay = switchImageFunction(codeDay);
                                        Object oNight = switchImageFunction(codeNight);
                                        map.put("imageDay",oDay);
                                        map.put("imageNight",oNight);

                                        map.put("wind_direction", arrayList1.get(i).getWind_direction());
                                        map.put("wind_scale", arrayList1.get(i).getWind_scale());
                                        list.add(map);
                                        //设置页面里的内容
                                        //封装到函数中
                                        if (i == 0) {
                                            addItem(map, v1);
                                        }
                                        //最高气温变化图，获得气温
                                        temperatureHigh[i] = Integer.parseInt(arrayList1.get(i).getHigh());
                                        temperatureLow[i] = Integer.parseInt(arrayList1.get(i).getLow());
                                        //
                                        SimpleAdapter simpleAdapter = new SimpleAdapter(
                                                AddWeatherActivity.this,
                                                list,
                                                R.layout.weatherlayout,             //layout界面 contact.xml文件
                                                new String[]{"city", "date", "text_day", "text_night", "high", "low","imageDay","imageNight"}, //键值对的键
                                                new int[]{R.id.cityWLayout, R.id.dateWLayout, R.id.daywWLayout, R.id.nightwWLyout, R.id.highWLyout, R.id.lowWLyout,R.id.imageWLD,R.id.imageWLN} //layout contact.xml文件中控件的id
                                        );
                                        weatherListView.setAdapter(simpleAdapter); //把适配器放进

                                    }
                                    LineChartView lineChartView = (LineChartView) v1.findViewById(R.id.lineview);
                                    //设置x轴
                                    setAxisLables(axisValues);
                                    //设置数值坐标点
                                    setAxisPoints(pointValues, temperatureHigh);
                                    setAxisPoints(pointValues1, temperatureLow);
                                    //线的设置
                                    initLineChart(lineChartView, pointValues, pointValues1, axisValues);


                                }
                            });
                        } else {
                            show();

                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        show1();
                    }
                }
            }.start();

            vpList.add(v1);
        }


        if(city2!=null &&city2!="") {

            new Thread() {
                public void run() {
                    try {
                        //输入的城市
                        final ArrayList<Weather> arrayList2;
                        String path = "https://api.seniverse.com/v3/weather/daily.json?key=SZRF79U_WCU9O3B-c&location=" + city2
                                + "&language=zh-Hans&unit=c&start=0&days=3";
                        URL url = new URL(path);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setReadTimeout(5000);
                        conn.setRequestMethod("GET");
                        if (conn.getResponseCode() == 200) {
                            InputStream inputStream = conn.getInputStream();
                            String str = "";
                            int len = 0;
                            byte[] bytes = new byte[1024];
                            while ((len = inputStream.read(bytes)) > 20) {
                                str += new String(bytes);

                            }
                            //查询结果
                            arrayList2 = MyJson.getWeather(str);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //添加到tempatureView
                                    //保存到list中
                                    //listView//数据值的点
                                    List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
                                    List<PointValue> pointValues = new ArrayList<PointValue>();
                                    List<PointValue> pointValues1 = new ArrayList<PointValue>();
                                    List<AxisValue> axisValues = new ArrayList<AxisValue>();
                                    ListView weatherListView = (ListView) v2.findViewById(R.id.weatherListView);
                                    for (int i = 0; i < 3; i++) {
                                        Map<String, Object> map = new HashMap<String, Object>();
                                        map.put("city", city2);
                                        map.put("date", arrayList2.get(i).getDate());
                                        map.put("low", arrayList2.get(i).getLow());
                                        map.put("high", arrayList2.get(i).getHigh());
                                        map.put("text_day", arrayList2.get(i).getText_day());
                                        map.put("text_night", arrayList2.get(i).getText_night());
                                        map.put("code_day", arrayList2.get(i).getCode_day());
                                        map.put("code_night", arrayList2.get(i).getCode_night());

                                        String codeDay = arrayList2.get(i).getCode_day();
                                        String codeNight = arrayList2.get(i).getCode_night();
                                        Object oDay = switchImageFunction(codeDay);
                                        Object oNight = switchImageFunction(codeNight);
                                        map.put("imageDay",oDay);
                                        map.put("imageNight",oNight);

                                        map.put("wind_direction", arrayList2.get(i).getWind_direction());
                                        map.put("wind_scale", arrayList2.get(i).getWind_scale());
                                        list.add(map);
                                        //设置页面里的内容
                                        //封装到函数中
                                        if (i == 0) {
                                            addItem(map, v2);
                                        }
                                        //最高气温变化图，获得气温
                                        temperatureHigh[i] = Integer.parseInt(arrayList2.get(i).getHigh());
                                        temperatureLow[i] = Integer.parseInt(arrayList2.get(i).getLow());
                                        //
                                        SimpleAdapter simpleAdapter = new SimpleAdapter(
                                                AddWeatherActivity.this,
                                                list,
                                                R.layout.weatherlayout,             //layout界面 contact.xml文件
                                                new String[]{"city", "date", "text_day", "text_night", "high", "low","imageDay","imageNight"}, //键值对的键
                                                new int[]{R.id.cityWLayout, R.id.dateWLayout, R.id.daywWLayout, R.id.nightwWLyout, R.id.highWLyout, R.id.lowWLyout,R.id.imageWLD,R.id.imageWLN} //layout contact.xml文件中控件的id
                                        );
                                        weatherListView.setAdapter(simpleAdapter); //把适配器放进

                                    }
                                    LineChartView lineChartView = (LineChartView) v2.findViewById(R.id.lineview);
                                    //设置x轴
                                    setAxisLables(axisValues);
                                    //设置数值坐标点
                                    setAxisPoints(pointValues, temperatureHigh);
                                    setAxisPoints(pointValues1, temperatureLow);
                                    //线的设置
                                    initLineChart(lineChartView, pointValues, pointValues1, axisValues);


                                }
                            });
                        } else {
                            show();

                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        show1();
                    }
                }
            }.start();

            vpList.add(v2);
        }

        if(city3!=null &&city3!="") {

            new Thread() {
                public void run() {
                    try {
                        //输入的城市
                        final ArrayList<Weather> arrayList3;
                        String path = "https://api.seniverse.com/v3/weather/daily.json?key=SZRF79U_WCU9O3B-c&location=" + city3
                                + "&language=zh-Hans&unit=c&start=0&days=3";
                        URL url = new URL(path);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setReadTimeout(5000);
                        conn.setRequestMethod("GET");
                        if (conn.getResponseCode() == 200) {
                            InputStream inputStream = conn.getInputStream();
                            String str = "";
                            int len = 0;
                            byte[] bytes = new byte[1024];
                            while ((len = inputStream.read(bytes)) > 20) {
                                str += new String(bytes);

                            }
                            //查询结果
                            arrayList3 = MyJson.getWeather(str);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //添加到tempatureView
                                    //保存到list中
                                    //listView//数据值的点
                                    List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
                                    List<PointValue> pointValues = new ArrayList<PointValue>();
                                    List<PointValue> pointValues1 = new ArrayList<PointValue>();
                                    List<AxisValue> axisValues = new ArrayList<AxisValue>();
                                    ListView weatherListView = (ListView) v3.findViewById(R.id.weatherListView);
                                    for (int i = 0; i < 3; i++) {
                                        Map<String, Object> map = new HashMap<String, Object>();
                                        map.put("city", city3);
                                        map.put("date", arrayList3.get(i).getDate());
                                        map.put("low", arrayList3.get(i).getLow());
                                        map.put("high", arrayList3.get(i).getHigh());
                                        map.put("text_day", arrayList3.get(i).getText_day());
                                        map.put("text_night", arrayList3.get(i).getText_night());
                                        map.put("code_day", arrayList3.get(i).getCode_day());
                                        map.put("code_night", arrayList3.get(i).getCode_night());

                                        String codeDay = arrayList3.get(i).getCode_day();
                                        String codeNight = arrayList3.get(i).getCode_night();
                                        Object oDay = switchImageFunction(codeDay);
                                        Object oNight = switchImageFunction(codeNight);
                                        map.put("imageDay",oDay);
                                        map.put("imageNight",oNight);

                                        map.put("wind_direction", arrayList3.get(i).getWind_direction());
                                        map.put("wind_scale", arrayList3.get(i).getWind_scale());
                                        list.add(map);
                                        //设置页面里的内容
                                        //封装到函数中
                                        if (i == 0) {
                                            addItem(map, v3);
                                        }
                                        //最高气温变化图，获得气温
                                        temperatureHigh[i] = Integer.parseInt(arrayList3.get(i).getHigh());
                                        temperatureLow[i] = Integer.parseInt(arrayList3.get(i).getLow());
                                        //
                                        SimpleAdapter simpleAdapter = new SimpleAdapter(
                                                AddWeatherActivity.this,
                                                list,
                                                R.layout.weatherlayout,             //layout界面 contact.xml文件
                                                new String[]{"city", "date", "text_day", "text_night", "high", "low","imageDay","imageNight"}, //键值对的键
                                                new int[]{R.id.cityWLayout, R.id.dateWLayout, R.id.daywWLayout, R.id.nightwWLyout, R.id.highWLyout, R.id.lowWLyout,R.id.imageWLD,R.id.imageWLN} //layout contact.xml文件中控件的id
                                        );
                                        weatherListView.setAdapter(simpleAdapter); //把适配器放进


                                    }
                                    LineChartView lineChartView = (LineChartView) v3.findViewById(R.id.lineview);
                                    //设置x轴
                                    setAxisLables(axisValues);
                                    //设置数值坐标点
                                    setAxisPoints(pointValues, temperatureHigh);
                                    setAxisPoints(pointValues1, temperatureLow);
                                    //线的设置
                                    initLineChart(lineChartView, pointValues, pointValues1, axisValues);


                                }
                            });
                        } else {
                            show();

                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        show1();
                    }
                }
            }.start();
            vpList.add(v3);
        }






        //将View添加到ViewPager

        //适配器，设置某一个界面的填充布局




        //适配器 ，adapter
        PagerAdapter pagerAdapter = new PagerAdapter() {
            @Override
            //数量
            public int getCount() {

                return vpList.size();
            }

            @Override
            //判断是否是有对象生成的界面
            public boolean isViewFromObject(View view, Object object) {

                return view==object;
            }

            //获取当前界面的位置
            public Object instantiateItem(ViewGroup viewGroup,int position){
                viewGroup.addView(vpList.get(position));

                return vpList.get(position);

            }

            //销毁上一个显示界面
            public  void destroyItem(ViewGroup viewGroup, int position, Object object){
                viewGroup.removeView(vpList.get(position));
            }

        };

        viewPager.setAdapter(pagerAdapter);
        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }
            //当界面被选中时
            @Override
            public void onPageSelected(int position) {
                switch (position){
                    case 0:
                        selectCity.setText(city1);
                        break;
                    case 1:
                        if(city2!=null && city2!="") {
                            selectCity.setText(city2);
                        }
                        break;
                    case 2:
                        if(city3!=null && city3!="") {
                            selectCity.setText(city3);
                        }
                        break;


                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {



            }
        });

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(AddWeatherActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });



    }




    private  void setAxisLables(List<AxisValue> axisValues1){
        for(int i=0;i<lineData.length;i++){
            axisValues1.add(new AxisValue(i).setLabel(lineData[i]));
        }
    }

    private void setAxisPoints(List<PointValue> pointValues1,int[] temperatureHigh){
        for(int i=0;i<temperatureHigh.length;i++){
            pointValues1.add(new PointValue(i,temperatureHigh[i]));
        }
    }

    //设置线形图的显示
    private void initLineChart(LineChartView lineChartView1, List<PointValue> pointValues, List<PointValue> pointValues1,List<AxisValue> axisValues1){
        //线的颜色，形状
        Line line = new Line();
        line.setColor(Color.parseColor("#C1380A"));
        line.setShape(ValueShape.CIRCLE); //设置圆形数据点
        line.setCubic(false); //设置曲线，折线
        line.setHasLabels(true);  //增加标注
        line.setValues(pointValues);

        Line line1 = new Line();
        line1.setColor(Color.parseColor("#33b5e5"));
        line1.setShape(ValueShape.CIRCLE); //设置圆形数据点
        line1.setCubic(false); //设置曲线，折线
        line1.setHasLabels(true);  //增加标注
        line1.setValues(pointValues1);


        List<Line> lines = new ArrayList<>();
        lines.add(line);
        lines.add(line1);
        LineChartData data = new LineChartData();
        data.setLines(lines);


        //x轴
        Axis axisX = new Axis();
        axisX.setTextColor(Color.BLACK);
        axisX.setValues(axisValues1);
        axisX.setHasLines(true);
        data.setAxisXBottom(axisX);

        //y轴
        Axis axisY = new Axis();
        axisY.setTextColor(Color.BLACK);
        data.setAxisYLeft(axisY);
        axisY.setTextSize(12);


        lineChartView1.setInteractive(true);
        lineChartView1.setMaxZoom(5);
        lineChartView1.setLineChartData(data);
        lineChartView1.setVisibility(View.VISIBLE);


    }

    private void addItem(Map<String, Object> map, View v1) {
        TextView cityName = v1.findViewById(R.id.cityName);
        cityName.setText(map.get("city").toString());
        TextView dateView = v1.findViewById(R.id.dateView);
        dateView.setText(map.get("date").toString());

        TextView lowView = v1.findViewById(R.id.lowView);
        lowView.setText("最低温度"+map.get("low").toString());
        TextView highView = v1.findViewById(R.id.highView);
        highView.setText("最高温度"+map.get("high").toString());

        TextView textdayView = v1.findViewById(R.id.textdayView);
        textdayView.setText("白天天气： "+map.get("text_day").toString());
        TextView textnightView = v1.findViewById(R.id.textnightView);
        textnightView.setText("夜间天气： "+map.get("text_night").toString());
        TextView codeday = v1.findViewById(R.id.codeday);
        codeday.setText(map.get("code_day").toString());
        TextView codenight = v1.findViewById(R.id.codenight);
        codenight.setText(map.get("code_night").toString());

        TextView windDirection = v1.findViewById(R.id.windDirection);
        windDirection.setText("风向"+map.get("wind_direction").toString());
        TextView windLevel = v1.findViewById(R.id.windLevel);
        windLevel.setText("风级"+map.get("wind_scale").toString());

        //根据天气代码查询图标
        ImageView imageDay = v1.findViewById(R.id.imageDay);
        ImageView imageNight = v1.findViewById(R.id.imageNight);
        switchImageFunction1(imageDay,codeday);
        switchImageFunction1(imageNight,codenight);

    }

    public Object switchImageFunction( String codeday1) {
        Integer codeInt = Integer.valueOf(codeday1);
        switch (codeInt){
            case 0:
                //imageDay.setImageResource(R.drawable.w0);
                return R.drawable.w0;

            case 1:
               // imageDay.setImageResource(R.drawable.w1);
                return  R.drawable.w1;

            case 2:
                //imageDay.setImageResource(R.drawable.w2);
                return  R.drawable.w2;

            case 3:
               // imageDay.setImageResource(R.drawable.w3);
                return R.drawable.w3;

            case 4:
//                imageDay.setImageResource(R.drawable.w4);
                return R.drawable.w4;

            case 5:
//                imageDay.setImageResource(R.drawable.w5);
                return R.drawable.w5;

            case 6:
//                imageDay.setImageResource(R.drawable.w6);
                return R.drawable.w6;

            case 7:
//                imageDay.setImageResource(R.drawable.w7);
                return R.drawable.w7;

            case 8:
//                imageDay.setImageResource(R.drawable.w8);
                return R.drawable.w8;

            case 9:
//                imageDay.setImageResource(R.drawable.w9);
                return R.drawable.w9;

            case 10:
//                imageDay.setImageResource(R.drawable.w10);
                return R.drawable.w10;

            case 11:
//                imageDay.setImageResource(R.drawable.w11);
                return R.drawable.w11;

            case 12:
//                imageDay.setImageResource(R.drawable.w12);
                return R.drawable.w12;

            case 13:
//                imageDay.setImageResource(R.drawable.w13);
                return R.drawable.w13;

            case 14:
//                imageDay.setImageResource(R.drawable.w14);
                return R.drawable.w14;

            case 15:
//                imageDay.setImageResource(R.drawable.w15);
                return R.drawable.w15;

            case 16:
//                imageDay.setImageResource(R.drawable.w16);
                return R.drawable.w16;

            case 17:
//                imageDay.setImageResource(R.drawable.w17);
                return R.drawable.w17;

            case 18:
//                imageDay.setImageResource(R.drawable.w18);
                return R.drawable.w18;

            case 19:
//                imageDay.setImageResource(R.drawable.w19);
                return R.drawable.w19;

            case 20:
//                imageDay.setImageResource(R.drawable.w20);
                return R.drawable.w20;

            case 21:
//                imageDay.setImageResource(R.drawable.w21);
                return R.drawable.w21;

            case 22:
//                imageDay.setImageResource(R.drawable.w22);
                return R.drawable.w22;

            case 23:
//                imageDay.setImageResource(R.drawable.w23);
                return R.drawable.w23;

            case 24:
//                imageDay.setImageResource(R.drawable.w24);
                return R.drawable.w24;

            case 25:
//                imageDay.setImageResource(R.drawable.w25);
                return R.drawable.w25;

            case 26:
//                imageDay.setImageResource(R.drawable.w26);
                return R.drawable.w26;

            case 27:
//                imageDay.setImageResource(R.drawable.w27);
                return R.drawable.w27;

            case 28:
//                imageDay.setImageResource(R.drawable.w28);
                return R.drawable.w28;

            case 29:
//                imageDay.setImageResource(R.drawable.w29);
                return R.drawable.w29;

            case 30:
//                imageDay.setImageResource(R.drawable.w30);
                return R.drawable.w30;

            case 31:
//                imageDay.setImageResource(R.drawable.w31);
                return R.drawable.w31;

            case 32:
//                imageDay.setImageResource(R.drawable.w32);
                return R.drawable.w32;

            case 33:
//                imageDay.setImageResource(R.drawable.w33);
                return R.drawable.w33;

            case 38:
//                imageDay.setImageResource(R.drawable.w38);
                return R.drawable.w38;

            case 99:
//                imageDay.setImageResource(R.drawable.w99);
                return R.drawable.w99;

            default:
                return R.drawable.w99;

        }


    }

    private void switchImageFunction1(ImageView imageDay, TextView codeday) {
        String code= codeday.getText().toString().trim();
        Integer codeInt = Integer.valueOf(code);
        switch (codeInt){
            case 0:
                imageDay.setImageResource(R.drawable.w0);
                break;
            case 1:
                imageDay.setImageResource(R.drawable.w1);
                break;
            case 2:
                imageDay.setImageResource(R.drawable.w2);
                break;
            case 3:
                imageDay.setImageResource(R.drawable.w3);
                break;
            case 4:
                imageDay.setImageResource(R.drawable.w4);
                break;
            case 5:
                imageDay.setImageResource(R.drawable.w5);
                break;
            case 6:
                imageDay.setImageResource(R.drawable.w6);
                break;
            case 7:
                imageDay.setImageResource(R.drawable.w7);
                break;
            case 8:
                imageDay.setImageResource(R.drawable.w8);
                break;
            case 9:
                imageDay.setImageResource(R.drawable.w9);
                break;
            case 10:
                imageDay.setImageResource(R.drawable.w10);
                break;
            case 11:
                imageDay.setImageResource(R.drawable.w11);
                break;
            case 12:
                imageDay.setImageResource(R.drawable.w12);
                break;
            case 13:
                imageDay.setImageResource(R.drawable.w13);
                break;
            case 14:
                imageDay.setImageResource(R.drawable.w14);
                break;
            case 15:
                imageDay.setImageResource(R.drawable.w15);
                break;
            case 16:
                imageDay.setImageResource(R.drawable.w16);
                break;
            case 17:
                imageDay.setImageResource(R.drawable.w17);
                break;
            case 18:
                imageDay.setImageResource(R.drawable.w18);
                break;
            case 19:
                imageDay.setImageResource(R.drawable.w19);
                break;
            case 20:
                imageDay.setImageResource(R.drawable.w20);
                break;
            case 21:
                imageDay.setImageResource(R.drawable.w21);
                break;
            case 22:
                imageDay.setImageResource(R.drawable.w22);
                break;
            case 23:
                imageDay.setImageResource(R.drawable.w23);
                break;
            case 24:
                imageDay.setImageResource(R.drawable.w24);
                break;
            case 25:
                imageDay.setImageResource(R.drawable.w25);
                break;
            case 26:
                imageDay.setImageResource(R.drawable.w26);
                break;
            case 27:
                imageDay.setImageResource(R.drawable.w27);
                break;
            case 28:
                imageDay.setImageResource(R.drawable.w28);
                break;
            case 29:
                imageDay.setImageResource(R.drawable.w29);
                break;
            case 30:
                imageDay.setImageResource(R.drawable.w30);
                break;
            case 31:
                imageDay.setImageResource(R.drawable.w31);
                break;
            case 32:
                imageDay.setImageResource(R.drawable.w32);
                break;
            case 33:
                imageDay.setImageResource(R.drawable.w33);
                break;
            case 38:
                imageDay.setImageResource(R.drawable.w38);
                break;
            case 99:
                imageDay.setImageResource(R.drawable.w99);
                break;
            default:
                imageDay.setImageResource(R.drawable.w99);
        }
    }


    public void show(){
        runOnUiThread(new Runnable() {
                          @Override
                          public void run() {
                              Toast.makeText(getApplicationContext(),"请求失败，返回值为200",Toast.LENGTH_SHORT).show();
                          }
                      }
        );
    }
    public void show1(){
        runOnUiThread(new Runnable() {
                          @Override
                          public void run() {
                              Toast.makeText(getApplicationContext(),"请求失败,异常错误",Toast.LENGTH_SHORT).show();
                          }
                      }
        );
    }
}
