package com.myapplication.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.myapplication.R;

public class RealWelcomeActivity extends AppCompatActivity {

    Boolean isFirst;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_real_welcome);

        //读取数据
        SharedPreferences sharedPreferences = getSharedPreferences("isFirstDownload",MODE_PRIVATE);
        isFirst = sharedPreferences.getBoolean("isFirstDownload",true);//找不到isFirst就赋值为true
        //如果用户第一次登入，进入到滑动界面Welcome2Activity,否则进入倒计时Welcome界面
        if(isFirst){
            startActivity( new Intent(RealWelcomeActivity.this,Welcome2Activity.class));
        }else{
            startActivity( new Intent(RealWelcomeActivity.this,WelcomeActivity.class));
        }
        //关闭当前页面
        finish();
        //实例化编辑器
        SharedPreferences.Editor editor=sharedPreferences.edit();
        //存入数据
        editor.putBoolean("isFirstDownload",false);
        //提交修改
        editor.commit();






    }
}
