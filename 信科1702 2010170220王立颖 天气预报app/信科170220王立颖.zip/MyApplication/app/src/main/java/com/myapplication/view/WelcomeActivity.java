package com.myapplication.view;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.myapplication.R;

import java.util.Timer;
import java.util.TimerTask;

public class WelcomeActivity extends AppCompatActivity {
    private TextView timeover;
    Timer timer = new Timer();
    int num =6; //想看到五，就从六开始
    private  RelativeLayout adL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        //多线程

        adL=(RelativeLayout)findViewById(R.id.adLayout);//Welcome.xml中的layout的id
        timeover = (TextView) findViewById(R.id.timeover);
        TimerTask task =new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        num--;
                        timeover.setText("-"+num+"秒 -\n跳过");
                        if( num<=1 ){
                            timer.cancel();//关闭计时器线程
                            Intent intent = new Intent();
                            intent.setClass(WelcomeActivity.this,LoginActivity.class);
                            startActivity(intent);
                            WelcomeActivity.this.finish(); //关闭这个界面，从登录界面就不会返回到广告界面
                        }
                    }
                });
            }

        };
        timer.schedule(task,1000,1000);
        //点击跳转，跳过广告
        timeover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timer.cancel();//关闭计时器线程
                Intent intent = new Intent();
                intent.setClass(WelcomeActivity.this,LoginActivity.class);
                startActivity(intent);
                WelcomeActivity.this.finish(); //关闭这个界面，从登录界面就不会返回到广告界面
            }
        });

        //点广告其他位置跳转其他页面
        adL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timer.cancel();//关闭计时器线程
                // 打开百度主页
                Uri uri = Uri.parse("https://m.jd.com");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
                WelcomeActivity.this.finish(); //关闭这个界面，从登录界面就不会返回到广告界面
            }
        });



    }
}
