package com.myapplication.view;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.myapplication.R;

import java.util.ArrayList;

public class Welcome2Activity extends AppCompatActivity {
    private ViewPager viewPager;
    private TextView textView5;
    private RadioGroup radioButtonGroup1;
    private RadioButton radioButton1;
    private RadioButton radioButton2;
    private RadioButton radioButton3;

    ArrayList<View> vpList;

    //声明数组，用来保存所有需要动态开启的权限
    private static String[] PERMISSION_STORGE={
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.INTERNET,
            Manifest.permission.MOUNT_UNMOUNT_FILESYSTEMS,
            Manifest.permission.CAMERA

    };
    //权限的请求编码
    //常量 1
    private  static  int REQUEST_PERMISSION_CODE = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome2);

//判断版本
        //如果版本大于5.0
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP){
            //如果没有被授权
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
                //在当前界面，请求数组的所有权限 --应该逐个请求
                ActivityCompat.requestPermissions(this,PERMISSION_STORGE,REQUEST_PERMISSION_CODE);//参数，请求的页面，请求的编码
            }

        }

        textView5 = (TextView) findViewById(R.id.textView5);
        radioButtonGroup1 = (RadioGroup) findViewById(R.id.radioButtonGroup1);
        radioButton1 = (RadioButton) findViewById(R.id.radioButton1);
        radioButton2 = (RadioButton) findViewById(R.id.radioButton2);
        radioButton3 = (RadioButton) findViewById(R.id.radioButton3);
        viewPager = (ViewPager) findViewById(R.id.viewPager);



        textView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(Welcome2Activity.this,LoginActivity.class);
                startActivity(intent);
                Welcome2Activity.this.finish();
            }
        });

        //适配器，设置某一个界面的填充布局
        LayoutInflater layoutInflater = LayoutInflater.from(this);
        View v1 = layoutInflater.inflate(R.layout.s1,null);
        View v2 = layoutInflater.inflate(R.layout.s2,null);
        View v3 = layoutInflater.inflate(R.layout.s3,null);
        vpList = new ArrayList<View>();
        vpList.add(v1);
        vpList.add(v2);
        vpList.add(v3);
        //适配器 ，adapter
        PagerAdapter pagerAdapter = new PagerAdapter() {
            @Override
            //数量
            public int getCount() {

                return vpList.size();
            }

            @Override
            //判断是否是有对象生成的界面
            public boolean isViewFromObject(View view, Object object) {

                return view==object;
            }

            //获取当前界面的位置
            public Object instantiateItem(ViewGroup viewGroup, int position){
                viewGroup.addView(vpList.get(position));

                return vpList.get(position);

            }

            //销毁上一个显示界面
            public  void destroyItem(ViewGroup viewGroup,int position,Object object){
                viewGroup.removeView(vpList.get(position));
            }

        };



        viewPager.setAdapter(pagerAdapter);

        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }
            //当界面被选中时
            @Override
            public void onPageSelected(int position) {
                switch (position){
                    case 0:
                        radioButton1.setChecked(true);
                        textView5.setVisibility(View.GONE);
                        break;

                    case 1:
                        radioButton2.setChecked(true);
                        textView5.setVisibility(View.GONE);
                        break;
                    case 2:
                        radioButton3.setChecked(true);
                        textView5.setVisibility(View.VISIBLE);
                        break;


                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        //按钮 选中内容变化
        radioButtonGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if( radioButton1.getId()==checkedId){
                    viewPager.setCurrentItem(0);
                }else if(radioButton2.getId()==checkedId){
                    viewPager.setCurrentItem(1);
                }else{
                    viewPager.setCurrentItem(2);

                }
            }
        });





    }
}

