package com.myapplication.view;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.myapplication.MainActivity;
import com.myapplication.R;
import com.myapplication.util.DBHelper2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import static com.myapplication.R.id.userName;

public class LoginActivity extends AppCompatActivity {

    EditText username, pwd, inputCode;
    Button login, exit;
    TextView register, showCode,forgetPassword ;
    private CheckBox checkPwdLogin;
    private ImageButton dropdownButton;

    List<HashMap<String,Object>> userList= new ArrayList<HashMap<String,Object>>();

    private PopupWindow popupWindow;
    private ListView  listView;


   com.myapplication.util.DBHelper2 dbHelper;

Boolean checkButtonFlag;

    public String yzm() {
        String str = "1,2,3,4,5,6,7,8,9,0,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z";
        String str2[] = str.split(",");
        Random rand = new Random();
        int index = 0;
        String randStr = "";
        for (int i = 0; i < 4; i++) {
            index = rand.nextInt(str2.length - 1);
            randStr += str2[index];
        }

        return randStr;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = (EditText) findViewById(userName);
        pwd = (EditText) findViewById(R.id.passWord);
        inputCode = (EditText) findViewById(R.id.inputCode);
        login = (Button) findViewById(R.id.loginButton);
        exit = (Button) findViewById(R.id.exitLogin);
        register = (TextView) findViewById(R.id.register);
        showCode = (TextView) findViewById(R.id.verification_code);
        checkPwdLogin = (CheckBox) findViewById(R.id.checkPwdLogin);
        dropdownButton = (ImageButton) findViewById(R.id.dropdown_button);
        listView = new ListView(LoginActivity.this);
        forgetPassword = (TextView) findViewById(R.id.forgetPassword);

        checkPwdLogin.setChecked(true);


        //创建连接，打开数据库
        dbHelper = new DBHelper2(LoginActivity.this);
        //数据库查询，初始化msgList
        //数据库查询语句，包装成了一个方法
        initLoginUserName();




        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
        forgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("fUserName",username.getText().toString());
                intent.setClass(LoginActivity.this, ForgetPasswordActivity.class);
                startActivity(intent);
            }
        });


        showCode.setText(yzm());
        showCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCode.setText(yzm());

            }
        });




        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username1 = username.getText().toString();//从输入框获得数据
                String password1 = pwd.getText().toString();
                String inputCode1 = inputCode.getText().toString();
                Boolean flagName = false; //用来查询用户是否存在
                Boolean flagPassword = false;//用来查询密码是否对应

                //先判断验证码是否正确
                if (!inputCode1.equals(showCode.getText())) {
                    Toast.makeText(LoginActivity.this, "验证码错误", Toast.LENGTH_SHORT).show();
                } else {
                    //数据库查询语句，根据用户名查询密码
                    String result = dbHelper.queryPasswordByName(username1);
                    //如果查询结果存在（表示存在这个账户）并且密码与输入的密码一致
                    if (result!=null && result!="" &&result.equals(password1)) {
                        flagName = true;
                        flagPassword = true;
                        //更新数据库
                        long update = dbHelper.update(username1, password1, 1);
                        if(update!=-1) {
                            HashMap<String, Object> map = new HashMap<String, Object>();
                            map.put("uName", username1);
                            map.put("drawable", R.drawable.xicon);
                            userList.add(map);
                            MyAdapter myAdapter = new MyAdapter(
                                    LoginActivity.this,
                                    userList,
                                    R.layout.dropdown_item,             //layout界面 contact.xml文件
                                    new String[]{"uName","drawable"}, //键值对的键
                                    new int[]{R.id.userListItem,R.id.delete} //layout contact.xml文件中控件的id
                            );
                            listView.setAdapter(myAdapter); //把适配器放进
                            Toast.makeText(LoginActivity.this,"查询成功，更新成功",Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(LoginActivity.this,"查询成功，更新失败",Toast.LENGTH_SHORT).show();
                        }

                    }

                     {
                        //flag为true表示用户存在
                        if (flagName && flagPassword) {
                            Intent intent = new Intent();
                            //设置intent传递的内容，键值对的形式 put方法，在后面获取值时要通过键值对的名来获取
                            intent.putExtra("Username", username1);
                            intent.setClass(LoginActivity.this, MainActivity.class);//第一个是当前Activity，第二个是要跳转的Activity
                            startActivity(intent);
                            LoginActivity.this.finish();
                        } else {
                            Toast.makeText(LoginActivity.this, "用户名或密码错误", Toast.LENGTH_SHORT).show();
                        }

                    }

                }


            }
        });

        dropdownButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (popupWindow != null) {
                    if (!popupWindow.isShowing()) {
                        popupWindow.showAsDropDown(username);
                    } else {
                        popupWindow.dismiss();
                    }
                } else {
                    int length = dbHelper.queryAllNameByIsSaver().length;
                    if ( length> 0) {
                        initPopView(dbHelper.queryAllNameByIsSaver());
                        if (! popupWindow.isShowing()) {
                            popupWindow.showAsDropDown(username);
                        } else {
                            popupWindow.dismiss();
                        }
                    } else {
                        Toast.makeText(LoginActivity.this, "无记录", Toast.LENGTH_LONG).show();

                    }

                }
            }

        });


    }
    private void initLoginUserName(){

        String[] usernames = dbHelper.queryAllNameByIsSaver();
        if (usernames.length > 0) {
            String tempName = usernames[usernames.length - 1];
            username.setText(tempName);
            username.setSelection(tempName.length());
            String tempPwd = dbHelper.queryPasswordByName(tempName);
            int checkFlag = dbHelper.queryIsSavedByName(tempName);
            if (checkFlag == 0) {
                checkPwdLogin.setChecked(false);
            } else if (checkFlag == 1) {
                checkPwdLogin.setChecked(true);
            }
            if(checkPwdLogin.isChecked()) {
                pwd.setText(tempPwd);
            }
        }

        username.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                pwd.setText("");
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    public void initPopView(String[] strings) {
     // Toast.makeText(LoginActivity.this, "initPopView初始化开始 strings.length="+strings.length, Toast.LENGTH_SHORT).show();
        for(int i=0;i<strings.length;i++) {//循环条件，不是最后一个
            //如果用户名和表中的第二列uname相同，falg赋值为true即用户已经存在
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("uName", strings[i]);
            map.put("drawable", R.drawable.xicon);
            userList.add(map);

        }
            //adapter
        MyAdapter myAdapter = new  MyAdapter(
                    LoginActivity.this,
                   userList,
                  R.layout.dropdown_item,             //layout界面 contact.xml文件
                  new String[]{"uName","drawable"}, //键值对的键
                   new int[]{R.id.userListItem,R.id.delete} //layout contact.xml文件中控件的id
           );
           listView.setAdapter( myAdapter); //把适配器放进

        // 定义popupWindow
        popupWindow = new PopupWindow(LoginActivity.this);
        // 设置宽度
        popupWindow.setWidth(username.getWidth());
        // 设置popupWindow的高度
        popupWindow.setHeight(200);
        // 为popupWindow填充内容
        popupWindow.setContentView(listView);
        // 点击popupWindow以外的区域，自动关闭popupWindow
        popupWindow.setOutsideTouchable(true);
        // 设置弹出窗口，显示的位置
        popupWindow.showAsDropDown(username, 0, 0);
        popupWindow.setFocusable(true);
       Toast.makeText(LoginActivity.this, "initPopView初始化结束成功,请再次点击", Toast.LENGTH_LONG).show();

    }
   //重写SimpleAdapter
   class MyAdapter extends SimpleAdapter {
        private List<HashMap<String, Object>> data;

       public MyAdapter(Context context, List<HashMap<String, Object>> data,
                         int resource, String[] from, int[] to) {
          super(context, data, resource, from, to);
           this.data = data;
       }
        @Override
       public int getCount() {
           return data.size();
       }
       @Override
       public  View getView(final int position, View convertView,
                            ViewGroup parent){
           System.out.println(position);
           LoginActivity.ViewHolder holder;
           if (convertView == null) {
               holder = new LoginActivity.ViewHolder();
               convertView = LayoutInflater.from(LoginActivity.this).inflate(
                       R.layout.dropdown_item, null);
               holder.btn = (ImageButton) convertView
                       .findViewById(R.id.delete);
               holder.tv = (TextView) convertView.findViewById(R.id.userListItem);
               convertView.setTag(holder);
           } else {
               holder = (LoginActivity.ViewHolder) convertView.getTag();
           }
           holder.tv.setText(data.get(position).get("uName").toString());
           holder.tv.setOnClickListener(new View.OnClickListener() {

               @Override
               public void onClick(View v) {
                   String[] usernames = dbHelper.queryAllNameByIsSaver();
                   username.setText(usernames[position]);
                   pwd.setText(dbHelper
                           .queryPasswordByName(usernames[position]));
                   popupWindow.dismiss();
               }
           });
           holder.btn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   String[] usernames = dbHelper.queryAllNameByIsSaver();
                   if (usernames.length > 0) {
                      // dbHelper.delete(usernames[position]);
                       String password = dbHelper.queryPasswordByName(usernames[position]);
                       dbHelper.update(usernames[position],password,0);
//                       userList.remove(position);
                   }
                   String[] newusernames = dbHelper.queryAllNameByIsSaver();
                   if (newusernames.length > 0) {
                       initPopView(newusernames);
                       popupWindow.showAsDropDown(username);
                   } else {
                       popupWindow.dismiss();
                       popupWindow = null;
                   }
               }
           });
           return convertView;
       }


   }
    class ViewHolder {
        public TextView tv;
        public ImageButton btn;
    }


      @Override
    protected void onStop() {
        super.onStop();
        dbHelper.cleanup();
    }

}

