package com.myapplication.util;

import android.provider.BaseColumns;

/**
 * Created by zuti666 on 2020/6/20.
 */

public class DBUser {
    public static final class User implements BaseColumns {
        public static final String USERNAME = "username";
        public static final String PASSWORD = "password";
        public static final String IMGURL = "imgurl";
        public static final String ISSAVED = "issaved";
    }

}
