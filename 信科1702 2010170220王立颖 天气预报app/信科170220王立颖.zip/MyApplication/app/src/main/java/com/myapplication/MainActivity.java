package com.myapplication;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.icu.text.DecimalFormat;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.myapplication.util.DBHelper2;
import com.myapplication.view.AddWeatherActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();

    String localCity;
    String cityL2;
    String cityL3;


    private Button addCityButton;
    private TextView cityView;
    private TextView localCityView;
    private ListView cityList;
    private Button toWeatherButton;
    private ImageView myImage;
    private TextView textViewUserName;




    com.myapplication.util.DBHelper2 dbHelper;


    //声明数组，用来保存所有需要动态开启的权限
    private static String[] PERMISSION_STORGE = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.INTERNET,
            Manifest.permission.MOUNT_UNMOUNT_FILESYSTEMS

    };
    //权限的请求编码
    //常量 1
    private static int REQUEST_PERMISSION_CODE = 1;


    //定位的管理器
    LocationManager locationManger;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //如果版本大于5.0
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
            //如果没有被授权
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                //在当前界面，请求数组的所有权限 --应该逐个请求
                ActivityCompat.requestPermissions(this, PERMISSION_STORGE, REQUEST_PERMISSION_CODE);//参数，请求的页面，请求的编码
            }

        }

        addCityButton = (Button) findViewById(R.id.addCityButton);
        cityView = (TextView) findViewById(R.id.cityView);
        cityList = (ListView) findViewById(R.id.cityList);
        toWeatherButton = (Button) findViewById(R.id.toWeatherButton);
        localCityView = (TextView) findViewById(R.id.localCityView);
         myImage = (ImageView) findViewById(R.id.myImage);
        textViewUserName = (TextView) findViewById(R.id.textViewUserName);

        dbHelper = new DBHelper2(MainActivity.this);
        final  String userName= getIntent().getStringExtra("Username");
        textViewUserName.setText("欢迎你"+userName);

        String imgUrl = dbHelper.queryImgUrlByName(userName);
        Glide.with(MainActivity.this).load(imgUrl).into(myImage);

//        String outputImage = getIntent().getStringExtra("outputImage");
//        String imagePath = getIntent().getStringExtra("imagePath");
//        SharedPreferences sharedPreferences6 = getSharedPreferences("imagePre", MODE_MULTI_PROCESS);
//        String imagePath= sharedPreferences6.getString("imagePath", "");//找不到就赋值为空
//        String outputImage= sharedPreferences6.getString("outputImage", "");//找不到l就赋值为空
//        if(imagePath!=null && imagePath!=""){
////            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
////            myImage.setImageBitmap(bitmap);
//            Glide.with(MainActivity.this).load(imagePath).into(myImage);
//        }else if(outputImage!=null && outputImage!=""){
//
////            Bitmap bitmap = BitmapFactory.decodeFile(outputImage);
//            myImage.setImageBitmap(bitmap);
//            Glide.with(MainActivity.this).load(outputImage).into(myImage);

//        }



        //读取数据
        SharedPreferences sharedPreferences = getSharedPreferences("locationCity", MODE_MULTI_PROCESS);
        localCity = sharedPreferences.getString("localCity", "");//找不到locationCity就赋值为空
        cityL2= sharedPreferences.getString("cityL2", "");//找不到l就赋值为空
        cityL3= sharedPreferences.getString("cityL3", "");//找不到2就赋值为空

        //定位管理
        locationManger = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Location lc = locationManger.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        if (!isGPSAble(locationManger)) {
            Toast.makeText(MainActivity.this, "未打开GPS", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivityForResult(intent, 0);
            MainActivity.this.finish();
        }
        //第一次进入进行定位

        //如果用户没有定位过，进行定位
        if (localCity.equals("") || localCity == null) {

            //获得当前城市位置
            if (lc != null) {
                localCity = getAddress(lc);
                localCityView.setText(localCity);
            }

        } else {
            localCityView.setText(localCity);

        }
        //实例化编辑器
        SharedPreferences.Editor editor = sharedPreferences.edit();
        //存入数据
        editor.putString("localCity", localCity);
        //提交修改
        editor.commit();
        editor.clear();

        //将定位所在城市添加到List
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("cityName",localCity);
        list.add(map);
        //adapter
        SimpleAdapter simpleAdapter= new SimpleAdapter(
                MainActivity.this,
                list,
                R.layout.citylayout,             //layout界面 contact.xml文件
                new String[]{"cityName"}, //键值对的键
                new int[]{R.id.cityName} //layout contact.xml文件中控件的id
        );
        cityList.setAdapter(simpleAdapter); //把适配器放进

        //如果数据库中存有数据，添加到listView
        if( cityL2!=null && cityL2!="") {
        Map<String,Object> map1 = new HashMap<String,Object>();
        map1.put("cityName",cityL2);
        list.add(map1);
        //adapter
        SimpleAdapter simpleAdapter1= new SimpleAdapter(
                MainActivity.this,
                list,
                R.layout.citylayout,             //layout界面 contact.xml文件
                new String[]{"cityName"}, //键值对的键
                new int[]{R.id.cityName} //layout contact.xml文件中控件的id
        );
        cityList.setAdapter(simpleAdapter); //把适配器放进
        }
        if( cityL3!=null && cityL3!="") {
        Map<String,Object> map2 = new HashMap<String,Object>();
        map2.put("cityName",cityL3);
        list.add(map2);
        //adapter
        SimpleAdapter simpleAdapter2= new SimpleAdapter(
                MainActivity.this,
                list,
                R.layout.citylayout,             //layout界面 contact.xml文件
                new String[]{"cityName"}, //键值对的键
                new int[]{R.id.cityName} //layout contact.xml文件中控件的id
        );
        cityList.setAdapter(simpleAdapter); //把适配器放进
        }





        addCityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customDialog();
            }

        });

        //练习，长按是弹窗，询问是否删除，是的话删除 ,删除：从ListView中remove掉这条记录，再重新加入适配器
        cityList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
                ab.setIcon(R.drawable.attention);          //弹框图片
                ab.setTitle("警告");                //弹框标题
                ab.setMessage("您是否要删除");    //弹框内容
                //选项，及对应的点击监听
                ab.setPositiveButton("是", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //进行删除操作 删除：从ListView中remove掉这条记录，再重新加入适配器
                        //listView.removeView(listView.getChildAt(position)); //从ListView中remove掉这条记录
                        list.remove(position);
                        //从数据库中移除
                        if(list.size()==1){
                            SharedPreferences sharedPreferences = getSharedPreferences("locationCity", MODE_MULTI_PROCESS);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            //存入数据
                            editor.putString("cityL2", "");
                            //提交修改
                            editor.commit();
                            editor.clear();
                        }
                        if(list.size()==2){
                            SharedPreferences sharedPreferences = getSharedPreferences("locationCity", MODE_MULTI_PROCESS);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            //存入数据
                            editor.putString("cityL3", "");
                            //提交修改
                            editor.commit();
                            editor.clear();
                        }
                        SimpleAdapter simpleAdapter= new SimpleAdapter(
                                MainActivity.this,
                                list,
                                R.layout.citylayout,             //layout界面 contact.xml文件
                                new String[]{"cityName"}, //键值对的键
                                new int[]{R.id.cityName} //layout contact.xml文件中控件的id
                        );
                        cityList.setAdapter(simpleAdapter); //把适配器放进


                    }
                });
                ab.setNegativeButton("否", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this,"明智的选择",Toast.LENGTH_LONG).show();
                    }
                });

                ab.create().show();                 //创建对象并显示出来

                return true;
            }
        });

        toWeatherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //将添加的城市传到下一个页面
                //遍历数组将其转化为List<String>
                ArrayList<String> stringList = new ArrayList<String>();
                Map<String,Object> map = new HashMap<String,Object>();
                String city;
                for(int i=0;i<list.size();i++){
                     map = list.get(i);
                     city =(String) map.get("cityName");
                     stringList.add(city);
                }
//                if(stringList.size()==0){
//                    stringList.add("南京");
//                    stringList.add("上海");
//                    stringList.add("北京");
//
//                }
//                if(stringList.size()==1){
//                    stringList.add("上海");
//                    stringList.add("北京");
//                }
//                if(stringList.size()==2){
//                    stringList.add("北京");
//                }
//                if(stringList.size()<3){
//                    Toast.makeText(getApplicationContext(),"三个城市",Toast.LENGTH_SHORT).show();
//                }

                Intent intent=new Intent(MainActivity.this,AddWeatherActivity.class);
                intent.putStringArrayListExtra("cityList",stringList);
                if(stringList.size()>=1) {
                    intent.putExtra("city1", stringList.get(0));
                }
                if(stringList.size()>=2) {
                    intent.putExtra("city2", stringList.get(1));
                }
                if(stringList.size()>=3) {
                    intent.putExtra("city3", stringList.get(2));
                }
                startActivity(intent);

            }
        });


    }


    private boolean isGPSAble(LocationManager locationManager) {
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ? true : false;
    }

    //查询当前城市
    public String getAddress(Location lc) {
        String local;
        if (lc != null) {

            //lc = locationManger.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            DecimalFormat df = new DecimalFormat(".00");
            Geocoder gc = new Geocoder(MainActivity.this);
            List<Address> addList = null;
            try {
                //sb.append("当前城市"+gc.getFromLocation(lc.getLatitude(),lc.getLongitude(),1).get(0))
                addList = gc.getFromLocation(lc.getLatitude(), lc.getLongitude(), 1);

            } catch (Exception e) {
                e.printStackTrace();
            }
            Address ad = addList.get(0);
            local = ad.getLocality();
        } else {
            local = "";
        }
        return local;
    }

    public void customDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        final AlertDialog dialog = builder.create();
        View dialogView = View.inflate(MainActivity.this, R.layout.addcitylayout, null);
        dialog.setView(dialogView);
        dialog.show();


        final EditText et_name = dialogView.findViewById(R.id.et_name); //搜索输入的文字
        final Button btn_login = dialogView.findViewById(R.id.btn_login);
        final Button btn_cancel = dialogView.findViewById(R.id.btn_cancel);
//点击进行添加

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = et_name.getText().toString();

                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(MainActivity.this, "搜索关键字不能为空", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    cityView.setText(name);
                    //保存到list中
                    Map<String, Object> map = new HashMap<String, Object>();
                    map.put("cityName", name);
                    if (list.size() < 3) {
                        list.add(map);
                        //添加到数据库中
                        if(list.size()==2){
                            SharedPreferences sharedPreferences = getSharedPreferences("locationCity", MODE_MULTI_PROCESS);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            //存入数据
                            editor.putString("cityL2", name);
                            //提交修改
                            editor.commit();
                            editor.clear();
                        }
                        if(list.size()==3){
                            SharedPreferences sharedPreferences = getSharedPreferences("locationCity", MODE_MULTI_PROCESS);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            //存入数据
                            editor.putString("cityL3", name);
                            //提交修改
                            editor.commit();
                            editor.clear();
                        }

                        //adapter
                        SimpleAdapter simpleAdapter = new SimpleAdapter(
                                MainActivity.this,
                                list,
                                R.layout.citylayout,             //layout界面 contact.xml文件
                                new String[]{"cityName"}, //键值对的键
                                new int[]{R.id.cityName} //layout contact.xml文件中控件的id
                        );
                        cityList.setAdapter(simpleAdapter); //把适配器放进

                    }
                }

                dialog.dismiss();
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
    }




}
