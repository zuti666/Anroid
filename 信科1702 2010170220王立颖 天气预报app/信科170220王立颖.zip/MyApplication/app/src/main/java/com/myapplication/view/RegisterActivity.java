package com.myapplication.view;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.ContentUris;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.myapplication.R;
import com.myapplication.util.DBHelper2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;

public class RegisterActivity extends AppCompatActivity {

    private EditText userNameRegister;
    private EditText passWordRegister;
    private Button registerCheck;
    private Button exitRegister;


    private Button addImageButton;
    private ImageView userImage;

    //添加头像
    public  static final  int TAKE_PHOTO = 1;
    public  static  final  int CHOOSE_PHOTO= 2;
    private Uri imageUri;
    Boolean chooseFlag=false;
    String choose;
    String choices[]={"相机","本地图片"}; //数组用来保存选型内容
    String imgUrLString;

    com.myapplication.util.DBHelper2 dbHelper;

    boolean flag=true;


    //声明数组，用来保存所有需要动态开启的权限
    private static String[] PERMISSION_STORGE={

            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA

    };
    //权限的请求编码
    //常量 1
    private  static  int REQUEST_PERMISSION_CODE = 1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        userNameRegister = (EditText) findViewById(R.id.userNameRegister);
        passWordRegister = (EditText) findViewById(R.id.passWordRegister);
        registerCheck = (Button) findViewById(R.id.registerCheck);
        exitRegister = (Button) findViewById(R.id.exitRegister);
        addImageButton = (Button) findViewById(R.id.addImageButton);
        userImage = (ImageView) findViewById(R.id.userImage);
        dbHelper = new DBHelper2(RegisterActivity.this);
        if(dbHelper==null){
            Toast.makeText(RegisterActivity.this,"初始化错误",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(RegisterActivity.this,"数据库初始化成功",Toast.LENGTH_SHORT).show();
        }

        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP){
            //如果没有被授权
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){
                //在当前界面，请求数组的所有权限 --应该逐个请求
                ActivityCompat.requestPermissions(this,PERMISSION_STORGE,REQUEST_PERMISSION_CODE);//参数，请求的页面，请求的编码
            }

        }

        //注册页面返回键
        exitRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterActivity.this.finish();
                Intent intent = new Intent();
                intent.setClass(RegisterActivity.this,LoginActivity.class);
                startActivity(intent);
            }
        });

        //创建连接，打开数据库
        //构造方法，创建对象

        //数据库，打开，可以写入
        //注册，向数据库中添加内容，还需要查询看是否已经存在，即使用到了数据库中的添加和查询
        registerCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //数据库查询语句，包装成了一个方法
                String[] usernames = dbHelper.queryAllUserName();
                for(int i=0 ;i<usernames.length;i++) {
                    //如果用户名和表中的第二列uname相同，falg赋值为false 即用户已经存在
                    if (userNameRegister.getText().toString().trim().equals(usernames[i])) {
                        flag = false;
                        Toast.makeText(RegisterActivity.this,"用户名已经存在"+userNameRegister.getText().toString().trim(),Toast.LENGTH_SHORT).show();
                    }
                }
                if(userNameRegister.getText().toString().trim().equals("")||passWordRegister.getText().toString().trim().equals("")){
                    flag=false;
                    Toast.makeText(RegisterActivity.this,"用户名或密码为空",Toast.LENGTH_SHORT).show();

                }
                if( imgUrLString==null || imgUrLString==""){
                    flag=false;
                    Toast.makeText(RegisterActivity.this,"头像不能为空",Toast.LENGTH_SHORT).show();
                }

                //当flag为true时，可以注册
                if(flag) {
                    //  insert方法添加数据 参数为 表名，，values集合
                    //Toast.makeText(RegisterActivity.this,"图片路径 imgUrl="+imgUrLString,Toast.LENGTH_SHORT).show();
                    long result = dbHelper.insertOrUpdateImgUrl(userNameRegister.getText().toString().trim(), passWordRegister.getText().toString().trim(),imgUrLString,0);
                    //dbHelper.cleanup();
                    if(result==-1)
                        {
                        Toast.makeText(RegisterActivity.this, "注册失败 db != null", Toast.LENGTH_SHORT).show();
                    }else if(result==-2){
                        Toast.makeText(RegisterActivity.this, "注册失败 db == null", Toast.LENGTH_SHORT).show();
                    }else{
                      //  插入成功，提示注册成功
                        Toast.makeText(RegisterActivity.this, "注册成功", Toast.LENGTH_SHORT).show();
                        //跳转到登录界面
                        Intent intent = new Intent();
                        intent.setClass(RegisterActivity.this, LoginActivity.class);
                        startActivity(intent);
                    }
                }
//                else{
//                    //flag为false提示出错
//
//                    flag=true;
//                }
            }
        });


        addImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder ab = new AlertDialog.Builder(RegisterActivity.this);
                ab.setIcon(R.drawable.choice);          //弹框图片
                ab.setTitle("请选择您添加方式");      //弹框标题
                //单选
                ab.setSingleChoiceItems(choices, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        choose =choices[which];
                    }
                });
                ab.setPositiveButton("取消",null);
                ab.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        chooseFlag=true;

                        if(chooseFlag && choose.equals("相机")&& choose!="" && choose!=null){
                            //创建Flie对象，用于存储拍照后的图片
//                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// HH:mm:ss
                            //获取当前时间
                            Date date = new Date(System.currentTimeMillis());
                            String dateString = date.toString();
                            File outputImage = new File(    getExternalCacheDir(),
                                    "output_image"+dateString+".jpg");
                            try{
                                if(outputImage.exists()){
                                    outputImage.delete();
                                }
                                outputImage.createNewFile();

                            }catch (IOException e){
                                e.printStackTrace();
                            }

                            if(Build.VERSION.SDK_INT>=24){
                                imageUri = FileProvider.getUriForFile(RegisterActivity.this,"com.myapplication.view.RegisterActivity.fileprovider",outputImage);

                            }else{
                                imageUri = Uri.fromFile(outputImage);
                            }
                            //启动相机程序
                            Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                            intent.putExtra(MediaStore.EXTRA_OUTPUT,imageUri);
                            startActivityForResult(intent,TAKE_PHOTO);
                            choose="";
                            chooseFlag=false;
                            //将图片路径存到数据库中
                            //读取数据
//                            SharedPreferences sharedPreferences = getSharedPreferences("imagePre",MODE_PRIVATE);
//                            SharedPreferences.Editor editor = sharedPreferences.edit();
//                            //存入数据
//                            editor.putString("outputImage",outputImage.getAbsolutePath());
//                            editor.putString("imagePath","");
//                            //提交修改
//                            editor.commit();
//                            editor.clear();
                            imgUrLString=outputImage.getAbsolutePath();

                        }else if(chooseFlag && choose.equals("本地图片")&& choose!="" && choose!=null){
                            //openAlbum();
                            Intent intent = new Intent("android.intent.action.GET_CONTENT");
                            intent.setType("image/*");
                            startActivityForResult(intent,CHOOSE_PHOTO);
                            choose="";
                            chooseFlag=false;
                        }
                    }
                });
                ab.create().show();                 //创建对象并显示出来


            }

        });


    }

    @Override
    protected void onStop() {
        super.onStop();
        dbHelper.cleanup();
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        switch (requestCode){
            case TAKE_PHOTO:
                if(resultCode == RESULT_OK){
                    try{
                        //将拍摄的照片显示出来
                        Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
                        userImage.setImageBitmap(bitmap);
                    }catch (FileNotFoundException e){
                        e.printStackTrace();
                    }

                }
                break;
            case CHOOSE_PHOTO:
                if(resultCode == RESULT_OK){
                    //判断手机系统版本号
                    if(Build.VERSION.SDK_INT >= 19){
                        //4.4系统及以上使用这个方法处理图片
                        handleImageOnKitKat(data);
                    }else{
                        //4.4系统及以下使用这个方法处理图片
                        handleImageBeforeKitKat(data);
                    }

                }
                break;
            default:
                break;
        }


    }


    @TargetApi(19)
    private void handleImageOnKitKat(Intent data){
        String imagePath = null;
        Uri uri = data.getData();
        if(DocumentsContract.isDocumentUri(this,uri)){
            //如果是document 类型的Uri ,则通过 document id 处理
            String docId = DocumentsContract.getDocumentId(uri);
            if("com.android.providers.media.documents".equals(uri.getAuthority())){
                String id = docId.split(":")[1]; //解析出数字格式的id
                String selection = MediaStore.Images.Media._ID+"="+id;
                imagePath = getImagePath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,selection);
            }else if("com.android.providers.downloads.documents".equals(uri.getAuthority())){
                Uri contentUri = ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"),Long.valueOf(docId));
            }
        }else if("content".equalsIgnoreCase(uri.getScheme())){
            //如果是content类型的Uri,则使用普通方式处理
            imagePath = getImagePath(uri,null);
        }else if("file".equalsIgnoreCase(uri.getScheme())){
            imagePath = uri.getPath();
        }
        displayImage(imagePath);//根据图片路径显示图片
//         //提交修改
//        editor.commit();
//        editor.clear();

        imgUrLString=imagePath;



    }
    private void handleImageBeforeKitKat(Intent data){
        Uri uri = data.getData();
        String imagePath = getImagePath(uri,null);
        displayImage(imagePath);

    }

    private String getImagePath(Uri uri ,String selection){
        String path =null;
        //通过Uri和selection 来获取真实的图片路径
        Cursor cursor = getContentResolver().query(uri,null,selection,null,null);
        if(cursor!=null){
            if(cursor.moveToFirst()){
                path= cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
            }
        }

        return path;
    }

    private  void displayImage(String imagePath){
        if(imagePath!=null){
            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
            userImage.setImageBitmap(bitmap);
        }else{
            Toast.makeText(this,"未能获取图片",Toast.LENGTH_SHORT).show();
        }

    }

}

