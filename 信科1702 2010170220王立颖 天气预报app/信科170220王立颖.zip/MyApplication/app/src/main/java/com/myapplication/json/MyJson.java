package com.myapplication.json;

import com.myapplication.utinity.Weather;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by zuti666 on 2020/4/30.
 */


public class MyJson {

    public static ArrayList<Weather> getWeather(String str) throws JSONException {
        ArrayList<Weather> arrayList=new ArrayList<>();

        JSONObject json = new JSONObject(str);
        JSONArray results = json.getJSONArray("results");

        JSONObject all = (JSONObject)results.get(0);
        String city = all.getJSONObject("location").getString("name");

        JSONArray daily = all.getJSONArray("daily");
        for(int i=0;i<daily.length();i++){
            Weather weather = new Weather();
            weather.setCity(city);
            JSONObject day = (JSONObject)daily.get(i);

            //日期
            String date = day.getString("date");
            weather.setDate(date);
            //最高气温
            String high = day.getString("high");
            weather.setHigh(high);
            //最低气温
            String low = day.getString("low");
            weather.setLow(low);
            //天气代码及天气
            String code_day = day.getString("code_day");
            weather.setCode_day(code_day);
            String code_night = day.getString("code_night");
            weather.setCode_night(code_night);
            String text_day = day.getString("text_day");
            weather.setText_day(text_day);
            String text_night= day.getString("text_night");
            weather.setText_night(text_night);

            //风力 风级
            String wind_direction = day.getString("wind_direction");
            weather.setWind_direction(wind_direction);
            String wind_scale = day.getString("wind_scale");
            weather.setWind_scale(wind_scale);

            //降水概率 降水量
            String precip=day.getString("precip");
            weather.setPrecip(precip);
            String rainfall=day.getString("rainfall");
            weather.setRainfall(rainfall);



            arrayList.add(weather);
        }
        return arrayList;
    }


}
